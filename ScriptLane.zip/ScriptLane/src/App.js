import './App.css';
import { Assignment } from './Assignment';

function App() {
  return (
    <div className="App">
      <Assignment />
    </div >
  );
}

export default App;
